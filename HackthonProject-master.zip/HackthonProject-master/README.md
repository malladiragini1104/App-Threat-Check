HackthonProject
===============
Title: App Threat Check. (Android) 

Team Details:
Team Name:Bazinga
1.Shashank Thakare
2.Manvesh Shandiliya
3.Pawan Gangad

Brief Idea:
1.Our App informs users about the security threat posed by its installed apps.

2.Based on weights (threat level) assigned to a permission(and not on total number of permissions),
this app displays the most dangerous apps.

3.Based on log analysis and device polling ,suggestions are given to user to block specific permissions;
And generate a new safe app(devoid of dangerous permissions) on a button click.

Setup Steps:
1.Xamarin studio used. Minimum API level is 14.

Note: 
As of now we have finished only the basic functionality of retrieving all apps on device; 
And displaying all permissions used by each app on a single click. 

