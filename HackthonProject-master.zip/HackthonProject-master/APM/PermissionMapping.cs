using System;
using System.Collections.Generic;

namespace APM
{
	public class PermissionMapping
	{
		public string Name  {
			get;
			set;
		}
		public int Weightage {
			get;
			set;
		}

//		public static Dictionary<int, string> PermissionMap = new Dictionary<int, string> () {
//			{5, READ_SMS},
//			{4, SEND_SMS},
//			{5, READ_CONTACTS},
//			{4, REBOOT},
//			{5, INTERNET},
//			{3, ACCESS_COARSE_LOCATION},
//			{4, ACCESS_FINE_LOCATION},
//			{3, WRITE_EXTERNAL_STORAGE},
//			{3, READ_HISTORY_BOOKMARKS},
//		
//	
//		};
	}
}

