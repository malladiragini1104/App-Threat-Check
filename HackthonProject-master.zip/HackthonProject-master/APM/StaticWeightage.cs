using System;
using System.Collections.Generic;

namespace APM
{
	public static class StaticWeightage
	{
		static StaticWeightage(){
			//ermis
		}	
			public static List<PermissionMapping> MyProperty {
			get;
			set;
		}
	}
}

